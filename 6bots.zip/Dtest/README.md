# SUPORT BY JhaiLBOTSprotect<br>
# selfpro NDOKceplok<br>
# AntiJs 6asist 1 ajs <br>


# HAPPY NEW YEARS 2019<br>


# Cara install <br>
# Install lib 2019 <br>
# git clone https://github.com/jhail212/Lib-JhaiLBOTS <br>



apt-get update -y <br>
pkg install python -y <br>
pkg install python2 -y <br>
apt-get install git -y <br>
apt-get install python3-pip -y <br> 
pip3 install rsa <br> 
pip3 install thrift==0.11.0 <br> 
pip3 install requests <br> 
pip3 install pytz <br> 
pip3 install bs4 <br> 
sudo pip3 install gtts <br> 
pip3 install googletrans <br> 
pip3 install humanfriendly<br> 
pip3 install goslate<br> 
pip3 install pafy<br> 
pip3 install wikipedia <br> 
pip3 install tweepy<br> 
pip3 install youtube_dl<br> 
git clone https://github.com/jhail212/AntiJs2019 <br> 
ls<br> 
cd AntiJs2019<br> 
ls<br> 
python3 7pro.py<br> 


Suport by: JhaiLBOTSprotect<br> 
                      NdokBOTSprotect<br> 
          
Note : Jika ingin instal pke vps tinggal tambah sudo di depan command<br> 


# Editor By JhaiLBOTSprotect<br> 
# Editor :
<a href="https://line.me/R/ti/p/~_agoest_"><img height="36" border="0" alt="Add Friend" src="https://scdn.line-apps.com/n/line_add_friends/btn/en.png"></a>

